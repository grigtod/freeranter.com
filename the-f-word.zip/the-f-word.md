+++
title = "F is for Friends"
date = "2021-04-26"
description = "People that use you are not your friends!"
tags = [
    "life",
]
+++ 

# The F word

There's been plenty of times when people I haven't talked to in years contact me for help. Occasionally I've helped them, but I've now decided to stop helping people that pretend to be my friends.







Three stories. One lesson.

1. 

When I was working on my MSc by Research I helped this guy for his thesis artefact. He's a really shitty programmer and I felt pity. After finishing uni I moved away and slowly we drifted apart. I didn't contact him, but he didn't keep in touch either. Then one day, a couple of weeks ago, he asked for my help and I helped him. I'm an idiot.
I helped him again a couple of days later. Some time passed and he sent me another cry for help, but this time his writing had a funny ring to them. It was a sort of entitlement. As if I have to help him. 
This got me thinking. This person only contacted me when he needed my help, otherwise he doesn't really care about me and here I am wasting my time on him. 


2. 

Another "friend" from uni that asked for my help. 4 years of radio silence. Last time I was hanging out with this guy we were working on a prototype for a museum, to start a sort of a side business. From other people I found out he took our prototype, removed my name from it and started showing it as his own creation. I did most of the prototype myself and he did some minor bits...
This sort of entitlement really struck me. You've not talked to me for years and think it's ok to ask for help out of the blue when you need me. 

3. 

I worked pro bono for this person. I helped her develop multiple projects and installations. I did it because I liked the challenge of the projects. Then one day I was helping on another project, but found out she was selling tickets for the experience I was helping develop. 
It showed me that in her head it's ok that I'm helping, but I'm not entitled for her revenue. Stopped all contact and blocked her.  





Two people I knew from uni contacted me recently, after 3 years of radio silence. Both of them needed my help and I helped them. I'm an idiot. 

They didn't care how I've been or bothered keeping in touch during all those years. I didn't either, but I didn't ask for their help. They asked for mine. 

One of them is a guy that's completing his PhD. A person that I practically tutored during his MSc (Res). Didn't keep in touch, only messaged me when he needed me. I should have refused and ignored, but decided to help him once again instead. Now he started behaving like he's entitled to my help, which got me thinking...

Why would I try to be nice and waste my time helping people that don't deserve it? I could be working on my personal projects and enriching my life, but instead I'm 




 
For one of them this wasn't enough and he started behaving like he's entitled to my help.





Freelancer, programmer, fan of free software (as in libre), ~~talking~~ ranting about life and tech.

This blog is hosted on [github pages](https://github.com/freeranter/freeranter.com). I'm using [Hugo](https://gohugo.io/), [this theme](https://github.com/janraasch/hugo-bearblog)  and [sitejs](https://sitejs.org/).
There's no tracking, so I have no idea how many of you are reading.

You can email me at user_name@host_name:
- user_name: freeranter
- host_name: protonmail.com or pm.me
